package brickbreaker;

public class BrickBreaker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GUI igra = new GUI();
	}

}
