package brickbreaker;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class GUI{
	Okvir glavni_okvir;
	double xLopte = 50, yLopte = 50, xDaske = 200, yDaske, visinaProzora, duzinaProzora, xDirLopte = -1, yDirLopte = -1, xCigle = 100, yCigle = 100;
	boolean prozor = false;

	private void build() {
		glavni_okvir = new Okvir(this);
	}
	public GUI() {
		build();
	}
	public void azuriraj() {
		Rectangle r = glavni_okvir.getBounds();
		visinaProzora = r.height;
		duzinaProzora = r.width;
		yDaske = r.height-50;
		prozor = true;
	}
}
