package brickbreaker;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.Timer;

import javax.swing.JFrame;

public class Okvir extends JFrame implements KeyListener, ActionListener{
	private Podloga podloga;
	private GUI gui;
	private Timer timer;
	private int delay = 8;

	private void build(GUI guil) {
		gui = guil;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(1000,500);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		Rectangle r = this.getBounds();
		
		timer = new Timer(delay, this);
		timer.start();
		gui.visinaProzora = r.height;
		gui.duzinaProzora = r.width;
		gui.yDaske = r.height-50;
		System.out.println(r.height);
		System.out.println(gui.yDaske);
		podloga = new Podloga(gui);
        this.addKeyListener(this);  
		this.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;
		
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		this.add(podloga, c);
		
		this.addComponentListener(new ComponentAdapter() {
		    public void componentResized(ComponentEvent componentEvent) {
		        gui.azuriraj();
		    }
		});
		
	}
	public Okvir(GUI gui1) {
		build(gui1);
	}
	@Override
	public void keyPressed(KeyEvent e) {
		switch(e.getKeyCode()) {
		case 37: 
			if(gui.xDaske < 10) break;
			gui.xDaske = gui.xDaske - 10;
			podloga.repaint();
			break;
		case 39: 
			Rectangle r = this.getBounds();
			if(gui.xDaske > r.width - 100 - 10) break;
			gui.xDaske = gui.xDaske + 10;
			podloga.repaint();
			break;
		}
	}
	
	
	
	
	@Override
	public void keyReleased(KeyEvent e) {}
	@Override
	public void keyTyped(KeyEvent e) {}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		timer.start();
		if(gui.xLopte > gui.xDaske && gui.xLopte < gui.xDaske + 100 && gui.yDaske + 10 == gui.yLopte + 10) {
			System.out.println("Kontakt");
			gui.yDirLopte = -gui.yDirLopte;
		}
		
		gui.xLopte += gui.xDirLopte;
		gui.yLopte += gui.yDirLopte;
		if(gui.xLopte < 0) {
			gui.xDirLopte = -gui.xDirLopte;
		}
		if(gui.yLopte < 0) {
			gui.yDirLopte = -gui.yDirLopte;
		}
		if(gui.xLopte + 10 > gui.duzinaProzora) {
			gui.xDirLopte = -gui.xDirLopte;
		}
		
		podloga.nacrtaj();
		
	}
}
