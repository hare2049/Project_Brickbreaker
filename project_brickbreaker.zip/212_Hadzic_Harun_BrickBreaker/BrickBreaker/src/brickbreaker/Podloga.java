package brickbreaker;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JPanel;

public class Podloga extends JPanel{
	private GUI gui;
	private LinkedList<Integer> cigle;
	private int d = 0;
	public Podloga(GUI guil){
		cigle = new LinkedList<Integer>();
		gui = guil;
		for(int i = 1; i < 11; i++) {
			cigle.addLast((int)gui.duzinaProzora/2 + i*50);
			cigle.addLast(25);
		}
		for(int i = 1; i < 11; i++) {
			cigle.addLast((int)gui.duzinaProzora/2 + i*50);
			cigle.addLast(100);
		}
		for(int i = 0; i < cigle.size()-1; i++) {
			System.out.println(cigle.get(i));
		}
		this.setBackground(Color.black);
	}
	public void paintComponent(Graphics g) {
		if(gui.prozor == true) {
			int m = 0;
			int y = 25;
			boolean t = true;
			System.out.println("u crtanju");
			for(int i = 0; i < cigle.size()-1; i = i + 2) {
				if(i < cigle.size()/2) {
					cigle.set(i, (int)gui.duzinaProzora/2 - (cigle.size()/8)*50 + m*50);
					m++;
					cigle.set(i+1, y);
				}
				else {
					if(t == true) {
						m = 0;
						y = 100;
						t = false;
					}
					cigle.set(i, (int)gui.duzinaProzora/2 - (cigle.size()/8)*50 +m*50);
					m++;
					cigle.set(i+1, y);
				}
			}
			gui.prozor = false;
		}
		super.paintComponent(g);
		g.setColor(Color.red);
		g.fillOval((int)gui.xLopte, (int)gui.yLopte, 10, 10);
		g.setColor(Color.white);
		
		for(int i = 0; i < cigle.size()-1; i = i + 2) {
			g.fillRect(cigle.get(i),cigle.get(i+1), 40, 25);
		}
		g.fillRect((int)gui.xDaske, (int)gui.yDaske, 100, 10);
	}
	public void nacrtaj() {
		repaint();
	}
}
